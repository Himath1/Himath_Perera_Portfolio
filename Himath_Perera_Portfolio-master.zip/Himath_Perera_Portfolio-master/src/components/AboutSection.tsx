import React from 'react';
import { motion } from 'framer-motion';
import { Section } from './ui/Section';
import {
  Shield,
  ShoppingBag,
  Megaphone,
  Code,
  Terminal,
  User } from
'lucide-react';
export function AboutSection() {
  const skills = [
  {
    name: 'Cybersecurity',
    icon: <Shield size={16} />,
    color: 'text-emerald-500',
    bg: 'bg-emerald-500/10'
  },
  {
    name: 'E-commerce',
    icon: <ShoppingBag size={16} />,
    color: 'text-purple-500',
    bg: 'bg-purple-500/10'
  },
  {
    name: 'Digital Advertising',
    icon: <Megaphone size={16} />,
    color: 'text-amber-500',
    bg: 'bg-amber-500/10'
  },
  {
    name: 'Web Development',
    icon: <Code size={16} />,
    color: 'text-blue-500',
    bg: 'bg-blue-500/10'
  }];

  return (
    <Section id="about" className="bg-slate-50 dark:bg-slate-900/50">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{
            opacity: 0,
            x: -20
          }}
          whileInView={{
            opacity: 1,
            x: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            duration: 0.6
          }}>

          <h2 className="text-3xl md:text-4xl font-bold font-mono text-slate-900 dark:text-white mb-6">
            <span className="text-cyan-500">01.</span> About Me
          </h2>

          <div className="space-y-4 text-slate-600 dark:text-slate-300 leading-relaxed">
            <p>
              I am a{' '}
              <strong className="text-cyan-600 dark:text-cyan-400">
                Cybersecurity Undergraduate
              </strong>{' '}
              pursuing my BSc (Hons) in IT with a specialization in Cyber
              Security. My academic journey is fueled by a passion for
              understanding complex digital systems and securing them against
              evolving threats.
            </p>
            <p>
              Beyond the terminal, I am a{' '}
              <strong className="text-cyan-600 dark:text-cyan-400">
                Tech Entrepreneur
              </strong>
              . I believe in the power of technology to solve real-world
              problems and create value. This drive has led me to found multiple
              ventures across different industries.
            </p>
            <p>
              Whether I'm analyzing network traffic or optimizing an ad
              campaign, I bring a data-driven, analytical approach to everything
              I do.
            </p>
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            {skills.map((skill) =>
            <span
              key={skill.name}
              className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${skill.bg} ${skill.color} border border-transparent hover:border-current transition-colors cursor-default`}>

                <span className="mr-2">{skill.icon}</span>
                {skill.name}
              </span>
            )}
          </div>
        </motion.div>

        <motion.div
          initial={{
            opacity: 0,
            x: 20
          }}
          whileInView={{
            opacity: 1,
            x: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            duration: 0.6,
            delay: 0.2
          }}
          className="relative flex flex-col items-center gap-8">

          {/* Profile Photo */}
          <div className="relative group">
            {/* Glow ring */}
            <div className="absolute -inset-1 bg-gradient-to-br from-blue-500 via-cyan-400 to-blue-600 rounded-2xl opacity-50 group-hover:opacity-75 blur-sm transition-opacity duration-500" />
            <div className="relative w-64 h-64 sm:w-80 sm:h-80 rounded-2xl overflow-hidden border-2 border-white/20 dark:border-slate-700/50 shadow-2xl">
              <img
                src="/images/profile.jpg"
                alt="Himath Himsara Perera"
                className="w-full h-full object-cover" />

              {/* Subtle overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/20 to-transparent" />
            </div>
          </div>

          {/* Terminal Card */}
          <div className="w-full relative">
            <div className="absolute inset-0 bg-cyan-500 blur-3xl opacity-10 rounded-full" />
            <div className="relative rounded-xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
              {/* Terminal Header */}
              <div className="bg-slate-100 dark:bg-slate-900 px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <div className="w-3 h-3 rounded-full bg-amber-500" />
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <div className="ml-4 text-xs text-slate-400 font-mono">
                  himath@portfolio:~/skills
                </div>
              </div>

              {/* Terminal Body */}
              <div className="p-6 font-mono text-sm space-y-4">
                <div className="flex">
                  <span className="text-green-500 mr-2">➜</span>
                  <span className="text-cyan-500 mr-2">~</span>
                  <span className="text-slate-600 dark:text-slate-300">
                    whoami
                  </span>
                </div>
                <div className="text-slate-500 dark:text-slate-400 pl-4">
                  "Himath Himsara Perera"
                  <br />
                  "Cybersecurity Student"
                  <br />
                  "Entrepreneur"
                </div>

                <div className="flex">
                  <span className="text-green-500 mr-2">➜</span>
                  <span className="text-cyan-500 mr-2">~</span>
                  <span className="text-slate-600 dark:text-slate-300">
                    ls ./ventures
                  </span>
                </div>
                <div className="text-slate-500 dark:text-slate-400 pl-4 grid grid-cols-1 gap-1">
                  <div className="flex items-center">
                    <span className="text-emerald-500 mr-2">drwx</span>{' '}
                    RiseUpCeylon (Clothing)
                  </div>
                  <div className="flex items-center">
                    <span className="text-amber-500 mr-2">drwx</span> NECXA
                    (Advertising)
                  </div>
                  <div className="flex items-center">
                    <span className="text-cyan-500 mr-2">drwx</span> EcomX
                    (Platform)
                  </div>
                </div>

                <div className="flex">
                  <span className="text-green-500 mr-2">➜</span>
                  <span className="text-cyan-500 mr-2">~</span>
                  <span className="text-slate-600 dark:text-slate-300 animate-pulse">
                    _
                  </span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </Section>);

}