import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Section } from './ui/Section';
import { Input } from './ui/Input';
import { TextArea } from './ui/TextArea';
import { Button } from './ui/Button';
import { Mail, Phone, Send, CheckCircle2 } from 'lucide-react';
export function ContactSection() {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formState.name.trim()) newErrors.name = 'Name is required';
    if (!formState.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formState.email)) {
      newErrors.email = 'Invalid email format';
    }
    if (!formState.message.trim()) newErrors.message = 'Message is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsSubmitting(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setIsSubmitting(false);
    setIsSuccess(true);
    setFormState({
      name: '',
      email: '',
      message: ''
    });
    // Reset success message after 5 seconds
    setTimeout(() => setIsSuccess(false), 5000);
  };
  const handleChange = (
  e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
  {
    const { name, value } = e.target;
    setFormState((prev) => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors((prev) => {
        const newErrors = {
          ...prev
        };
        delete newErrors[name];
        return newErrors;
      });
    }
  };
  return (
    <Section id="contact" className="bg-slate-50 dark:bg-slate-900/50">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
        {/* Contact Info */}
        <motion.div
          initial={{
            opacity: 0,
            x: -20
          }}
          whileInView={{
            opacity: 1,
            x: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            duration: 0.6
          }}>

          <h2 className="text-3xl md:text-4xl font-bold font-mono text-slate-900 dark:text-white mb-6">
            <span className="text-cyan-500">03.</span> Get In Touch
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mb-10 text-lg">
            Whether you have a project in mind, a question about cybersecurity,
            or just want to connect, feel free to reach out.
          </p>

          <div className="space-y-6">
            <a
              href="mailto:himathpereraap@gmail.com"
              className="flex items-center p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-cyan-500 dark:hover:border-cyan-500 transition-colors group">

              <div className="p-3 rounded-full bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 group-hover:bg-cyan-500 group-hover:text-white transition-colors">
                <Mail size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">
                  Email
                </p>
                <p className="text-slate-900 dark:text-white font-mono">
                  himathpereraap@gmail.com
                </p>
              </div>
            </a>

            <a
              href="tel:0719170384"
              className="flex items-center p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-cyan-500 dark:hover:border-cyan-500 transition-colors group">

              <div className="p-3 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                <Phone size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">
                  WhatsApp / Phone
                </p>
                <p className="text-slate-900 dark:text-white font-mono">
                  071 917 0384
                </p>
              </div>
            </a>
          </div>
        </motion.div>

        {/* Contact Form */}
        <motion.div
          initial={{
            opacity: 0,
            x: 20
          }}
          whileInView={{
            opacity: 1,
            x: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            duration: 0.6,
            delay: 0.2
          }}
          className="bg-white dark:bg-slate-900 p-8 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-800">

          {isSuccess ?
          <div className="h-full flex flex-col items-center justify-center text-center py-12">
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mb-4">
                <CheckCircle2 className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
                Message Sent!
              </h3>
              <p className="text-slate-600 dark:text-slate-400">
                Thanks for reaching out. I'll get back to you as soon as
                possible.
              </p>
              <Button
              variant="outline"
              className="mt-8"
              onClick={() => setIsSuccess(false)}>

                Send Another Message
              </Button>
            </div> :

          <form onSubmit={handleSubmit} className="space-y-6">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                Send a Message
              </h3>

              <Input
              label="Name"
              name="name"
              placeholder="Your Name"
              value={formState.name}
              onChange={handleChange}
              error={errors.name} />


              <Input
              label="Email"
              name="email"
              type="email"
              placeholder="your.email@example.com"
              value={formState.email}
              onChange={handleChange}
              error={errors.email} />


              <TextArea
              label="Message"
              name="message"
              placeholder="How can I help you?"
              value={formState.message}
              onChange={handleChange}
              error={errors.message} />


              <Button
              type="submit"
              className="w-full"
              size="lg"
              isLoading={isSubmitting}
              rightIcon={<Send size={18} />}>

                Send Message
              </Button>
            </form>
          }
        </motion.div>
      </div>
    </Section>);

}