import React from 'react';
import { Github, Linkedin, Instagram } from 'lucide-react';
export function Footer() {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-left">
          <p className="text-slate-600 dark:text-slate-400 font-mono text-sm">
            &copy; {currentYear} Himath Himsara Perera. All rights reserved.
          </p>
        </div>

        <div className="flex items-center space-x-6">
          <a
            href="#"
            className="text-slate-400 hover:text-cyan-500 dark:hover:text-cyan-400 transition-colors"
            aria-label="LinkedIn">

            <Linkedin size={20} />
          </a>
          <a
            href="#"
            className="text-slate-400 hover:text-cyan-500 dark:hover:text-cyan-400 transition-colors"
            aria-label="GitHub">

            <Github size={20} />
          </a>
          <a
            href="#"
            className="text-slate-400 hover:text-cyan-500 dark:hover:text-cyan-400 transition-colors"
            aria-label="Instagram">

            <Instagram size={20} />
          </a>
        </div>
      </div>
    </footer>);

}