import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { Button } from './ui/Button';
export function HeroSection() {
  const scrollToProjects = () => {
    document.getElementById('projects')?.scrollIntoView({
      behavior: 'smooth'
    });
  };
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({
      behavior: 'smooth'
    });
  };
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">

      {/* Background Grid */}
      <div className="absolute inset-0 z-0 opacity-20 dark:opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-grid-pattern-light dark:bg-grid-pattern bg-[length:40px_40px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-slate-50 dark:to-slate-950" />
      </div>

      {/* Floating Elements */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-cyan-500/20 rounded-full blur-3xl animate-pulse-slow pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-pulse-slow delay-1000 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.5
          }}>

          <span className="inline-block py-1 px-3 rounded-full bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 text-sm font-mono font-medium mb-6 border border-cyan-500/20">
            Hello, I'm
          </span>
        </motion.div>

        <motion.h1
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.5,
            delay: 0.1
          }}
          className="text-4xl sm:text-5xl md:text-7xl font-bold font-mono text-slate-900 dark:text-white tracking-tight mb-6">

          Himath Himsara <span className="text-cyan-500">Perera</span>
        </motion.h1>

        <motion.h2
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.5,
            delay: 0.2
          }}
          className="text-xl sm:text-2xl md:text-3xl text-slate-600 dark:text-slate-300 mb-8 max-w-3xl mx-auto">

          Cybersecurity Undergraduate{' '}
          <span className="text-cyan-500 mx-2">|</span> Tech Entrepreneur
        </motion.h2>

        <motion.p
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.5,
            delay: 0.3
          }}
          className="text-base sm:text-lg text-slate-500 dark:text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">

          Specializing in securing digital infrastructures while building
          innovative solutions in e-commerce and advertising.
        </motion.p>

        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.5,
            delay: 0.4
          }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4">

          <Button
            size="lg"
            onClick={scrollToProjects}
            rightIcon={<ArrowRight size={18} />}
            className="w-full sm:w-auto">

            View My Work
          </Button>
          <Button
            variant="outline"
            size="lg"
            onClick={scrollToContact}
            className="w-full sm:w-auto">

            Get In Touch
          </Button>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{
          opacity: 0
        }}
        animate={{
          opacity: 1
        }}
        transition={{
          delay: 1,
          duration: 1
        }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">

        <ChevronDown className="text-slate-400 dark:text-slate-600" size={24} />
      </motion.div>
    </section>);

}