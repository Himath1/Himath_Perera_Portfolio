import React, { useEffect, useState } from 'react';
import { Moon, Sun, Menu, X, Terminal } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
interface NavbarProps {
  isDark: boolean;
  toggleTheme: () => void;
}
export function Navbar({ isDark, toggleTheme }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('');
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
      // Track active section
      const sections = ['about', 'projects', 'contact'];
      for (const section of sections.reverse()) {
        const el = document.getElementById(section);
        if (el && window.scrollY >= el.offsetTop - 200) {
          setActiveSection(section);
          break;
        }
      }
      if (window.scrollY < 200) setActiveSection('');
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  const navLinks = [
  {
    name: 'About',
    href: '#about'
  },
  {
    name: 'Projects',
    href: '#projects'
  },
  {
    name: 'Contact',
    href: '#contact'
  }];

  const handleScrollTo = (
  e: React.MouseEvent<HTMLAnchorElement>,
  href: string) =>
  {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth'
      });
      setIsMobileMenuOpen(false);
    }
  };
  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'bg-white/70 dark:bg-slate-950/70 backdrop-blur-xl border-b border-slate-200/50 dark:border-blue-900/30 py-2.5 shadow-sm shadow-blue-900/5 dark:shadow-blue-950/20' : 'bg-transparent py-5'}`}>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#"
            onClick={(e) => handleScrollTo(e, '#hero')}
            className="flex items-center space-x-2.5 group">

            <motion.div
              whileHover={{
                rotate: 6,
                scale: 1.05
              }}
              transition={{
                type: 'spring',
                stiffness: 400,
                damping: 15
              }}
              className="p-2 rounded-xl bg-blue-600/10 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400 group-hover:bg-blue-600/20 dark:group-hover:bg-blue-500/20 transition-colors duration-300">

              <Terminal size={22} />
            </motion.div>
            <span className="text-lg font-mono font-bold text-slate-900 dark:text-white hidden sm:block tracking-tight">
              H.H.P<span className="text-blue-600 dark:text-blue-400">_</span>
            </span>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-1">
            {navLinks.map((link, index) => {
              const isActive = activeSection === link.href.replace('#', '');
              return (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleScrollTo(e, link.href)}
                  className={`relative px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${isActive ? 'text-blue-700 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400 hover:text-blue-700 dark:hover:text-blue-400'}`}>

                  {isActive &&
                  <motion.div
                    layoutId="activeNav"
                    className="absolute inset-0 bg-blue-600/8 dark:bg-blue-500/10 rounded-lg"
                    transition={{
                      type: 'spring',
                      stiffness: 350,
                      damping: 30
                    }} />

                  }
                  <span className="relative z-10 flex items-center">
                    <span className="text-blue-500 dark:text-blue-500 mr-1.5 font-mono text-[11px] opacity-60">
                      0{index + 1}.
                    </span>
                    {link.name}
                  </span>
                </a>);

            })}

            <div className="w-px h-5 bg-slate-200 dark:bg-slate-700/50 mx-3" />

            <motion.button
              whileHover={{
                scale: 1.05
              }}
              whileTap={{
                scale: 0.95
              }}
              onClick={toggleTheme}
              className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:text-blue-700 dark:hover:text-blue-400 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500/40"
              aria-label="Toggle dark mode">

              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={isDark ? 'sun' : 'moon'}
                  initial={{
                    rotate: -90,
                    opacity: 0,
                    scale: 0.5
                  }}
                  animate={{
                    rotate: 0,
                    opacity: 1,
                    scale: 1
                  }}
                  exit={{
                    rotate: 90,
                    opacity: 0,
                    scale: 0.5
                  }}
                  transition={{
                    duration: 0.2
                  }}>

                  {isDark ? <Sun size={16} /> : <Moon size={16} />}
                </motion.div>
              </AnimatePresence>
            </motion.button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-3">
            <motion.button
              whileTap={{
                scale: 0.9
              }}
              onClick={toggleTheme}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400">

              {isDark ? <Sun size={16} /> : <Moon size={16} />}
            </motion.button>
            <motion.button
              whileTap={{
                scale: 0.9
              }}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors">

              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={isMobileMenuOpen ? 'close' : 'menu'}
                  initial={{
                    rotate: -90,
                    opacity: 0
                  }}
                  animate={{
                    rotate: 0,
                    opacity: 1
                  }}
                  exit={{
                    rotate: 90,
                    opacity: 0
                  }}
                  transition={{
                    duration: 0.15
                  }}>

                  {isMobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
                </motion.div>
              </AnimatePresence>
            </motion.button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen &&
        <motion.div
          initial={{
            opacity: 0,
            height: 0
          }}
          animate={{
            opacity: 1,
            height: 'auto'
          }}
          exit={{
            opacity: 0,
            height: 0
          }}
          transition={{
            duration: 0.25,
            ease: [0.4, 0, 0.2, 1]
          }}
          className="md:hidden bg-white/90 dark:bg-slate-950/90 backdrop-blur-xl border-b border-slate-200/50 dark:border-blue-900/20 overflow-hidden">

            <div className="px-4 py-3 space-y-1">
              {navLinks.map((link, index) => {
              const isActive = activeSection === link.href.replace('#', '');
              return (
                <motion.a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleScrollTo(e, link.href)}
                  initial={{
                    opacity: 0,
                    x: -12
                  }}
                  animate={{
                    opacity: 1,
                    x: 0
                  }}
                  transition={{
                    delay: index * 0.05
                  }}
                  className={`block px-4 py-3 rounded-xl text-base font-medium transition-all duration-300 ${isActive ? 'bg-blue-600/10 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900/50 hover:text-blue-700 dark:hover:text-blue-400'}`}>

                    <span className="text-blue-500 mr-2 font-mono text-xs opacity-50">
                      0{index + 1}.
                    </span>
                    {link.name}
                  </motion.a>);

            })}
            </div>
          </motion.div>
        }
      </AnimatePresence>
    </nav>);

}