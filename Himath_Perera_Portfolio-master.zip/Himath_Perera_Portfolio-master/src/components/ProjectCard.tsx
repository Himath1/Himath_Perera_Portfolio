import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, ArrowUpRight } from 'lucide-react';
interface ProjectCardProps {
  title: string;
  role: string;
  description: string;
  accentColor: string;
  icon?: React.ReactNode;
  delay?: number;
}
export function ProjectCard({
  title,
  role,
  description,
  accentColor,
  icon,
  delay = 0
}: ProjectCardProps) {
  return (
    <motion.div
      initial={{
        opacity: 0,
        y: 20
      }}
      whileInView={{
        opacity: 1,
        y: 0
      }}
      viewport={{
        once: true
      }}
      transition={{
        duration: 0.5,
        delay
      }}
      whileHover={{
        y: -5
      }}
      className="group relative flex flex-col h-full bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm hover:shadow-xl hover:shadow-cyan-500/5 transition-all duration-300">

      {/* Top Accent Line */}
      <div className={`h-1 w-full ${accentColor}`} />

      <div className="p-6 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-4">
          <div
            className={`p-3 rounded-lg ${accentColor.replace('bg-', 'bg-opacity-10 text-').replace('text-', '')} bg-opacity-10`}>

            {icon}
          </div>
          <div className="px-3 py-1 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
            {role}
          </div>
        </div>

        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 group-hover:text-cyan-500 transition-colors">
          {title}
        </h3>

        <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed mb-6 flex-1">
          {description}
        </p>

        <div className="mt-auto pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <span className="text-xs font-mono text-slate-400">View Details</span>
          <div className="p-2 rounded-full bg-slate-50 dark:bg-slate-800 text-slate-400 group-hover:bg-cyan-500 group-hover:text-white transition-all duration-300">
            <ArrowUpRight size={16} />
          </div>
        </div>
      </div>
    </motion.div>);

}