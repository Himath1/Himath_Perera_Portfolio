import React from 'react';
import { Section } from './ui/Section';
import { ProjectCard } from './ProjectCard';
import { Shirt, Monitor, ShoppingCart } from 'lucide-react';
export function ProjectsSection() {
  const projects = [
  {
    title: 'RiseUpCeylon',
    role: 'Co-founder',
    description:
    'A modern Sri Lankan clothing brand blending local culture with contemporary streetwear aesthetics. Focused on quality fabrics and unique designs.',
    accentColor: 'bg-emerald-500',
    icon: <Shirt size={24} className="text-emerald-500" />
  },
  {
    title: 'NECXA Advertising',
    role: 'Founder',
    description:
    'Strategic outdoor advertising solutions connecting brands with audiences through high-impact physical media placements across key urban locations.',
    accentColor: 'bg-amber-500',
    icon: <Monitor size={24} className="text-amber-500" />
  },
  {
    title: 'EcomX',
    role: 'Founder',
    description:
    'A full-featured e-commerce platform enabling businesses to launch and scale their online presence effortlessly with integrated payments and inventory management.',
    accentColor: 'bg-cyan-500',
    icon: <ShoppingCart size={24} className="text-cyan-500" />
  }];

  return (
    <Section id="projects" className="relative">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-3xl h-full bg-cyan-500/5 blur-3xl -z-10 rounded-full" />

      <div className="mb-16">
        <h2 className="text-3xl md:text-4xl font-bold font-mono text-slate-900 dark:text-white mb-4">
          <span className="text-cyan-500">02.</span> Ventures & Projects
        </h2>
        <p className="text-slate-600 dark:text-slate-400 max-w-2xl">
          A collection of my entrepreneurial ventures and technical projects.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projects.map((project, index) =>
        <ProjectCard key={project.title} {...project} delay={index * 0.1} />
        )}
      </div>
    </Section>);

}