import React from 'react';
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}
export function Input({
  label,
  error,
  className = '',
  id,
  ...props
}: InputProps) {
  const inputId = id || props.name;
  return (
    <div className="w-full">
      {label &&
      <label
        htmlFor={inputId}
        className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">

          {label}
        </label>
      }
      <input
        id={inputId}
        className={`
          w-full px-4 py-2.5 rounded-lg border bg-white dark:bg-slate-900 
          text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500
          transition-colors duration-200
          focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500
          ${error ? 'border-red-500 focus:ring-red-500/50 focus:border-red-500' : 'border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-600'}
          ${className}
        `}
        {...props} />

      {error &&
      <p className="mt-1 text-sm text-red-500 animate-in slide-in-from-top-1 fade-in duration-200">
          {error}
        </p>
      }
    </div>);

}