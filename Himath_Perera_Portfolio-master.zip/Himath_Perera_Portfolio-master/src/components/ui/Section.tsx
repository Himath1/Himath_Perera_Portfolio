import React from 'react';
interface SectionProps {
  id: string;
  children: React.ReactNode;
  className?: string;
}
export function Section({ id, children, className = '' }: SectionProps) {
  return (
    <section
      id={id}
      className={`py-20 md:py-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full ${className}`}>

      {children}
    </section>);

}